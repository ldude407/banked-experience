# Changelog
    
    Release 1.0.3
        * Updated to work with '[Resource Packs](https://github.com/melkypie/resource-packs)' 1.0.3.
        * Added 'Is this Safe to use/Can I get banned for using this?' to the Readme to clear up confusion.
        * Updated the style of the changelog shown here.
    Release 1.0.2
        * Updated to work with '[Resource Packs](https://github.com/melkypie/resource-packs)' 1.0.2.
    Release 1.0.0
        * Initial release.
